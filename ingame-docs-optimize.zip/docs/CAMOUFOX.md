> Generated on 2026-06-03 (migrated from AGENTS.md). Если код противоречит этому доку — верь коду и обнови через subagent `scribe`.

# Camoufox Browser Configuration

Live runtime использует Camoufox (anti-detect Firefox) для всех CyberScore page fetches:
- **Mode**: One-shot per cycle (без long-living pages, без live-watcher). Каждый цикл — свежая страница: открыть, fetch, parse, закрыть.
- **Humanize**: `True` (макс реализм курсора, до 1.5с на движение).
- **Window**: авто-генерируемый случайный реалистичный размер (без фиксации — избегаем fingerprinting).
- **Locale**: авто из proxy IP через GeoIP.
- **OS fingerprint**: `windows`.
- **GeoIP**: включён — timezone, geolocation, locale матчат proxy IP.
- **WebRTC**: блокирован (`block_webrtc=True`).
- **Cache**: отключён (`enable_cache=False`).
- **Proxy**: обязателен; direct-запросы к CyberScore отключены.

Env overrides (все опциональны):

| Variable | Default | Description |
|---|---|---|
| `CYBERSCORE_CAMOUFOX_HUMANIZE` | `true` | Cursor humanization (true/false/float) |
| `CYBERSCORE_CAMOUFOX_OS` | `windows` | Target OS fingerprint |
| `CYBERSCORE_CAMOUFOX_LOCALE` | _(empty, auto geoip)_ | Force locale |
| `CYBERSCORE_CAMOUFOX_WINDOW` | _(empty, auto random)_ | Force window size e.g. `1920x1080` |
| `CYBERSCORE_CAMOUFOX_BLOCK_WEBRTC` | `1` | Block WebRTC |
| `CYBERSCORE_CAMOUFOX_ENABLE_CACHE` | `0` | Browser cache |
| `CYBERSCORE_CAMOUFOX_GEOIP` | `1` | GeoIP locale/timezone matching |
| `CYBERSCORE_LONG_PAGE_ENABLED` | `0` | Long-living page mode (disabled) |
| `CYBERSCORE_LIVE_WATCHER_ENABLED` | `0` | Live watcher mode (disabled) |

## Букмекеры и API

- DLTV Selenium (headless Chrome) — парсинг live-матчей.
- Букмекерские сайты через Selenium (headless) и Camoufox.
- Прокси-пулы для обхода лимитов (настраиваются в `base/keys.py`).
- Lock-файлы — против multiple instances. Sharded stats — оптимизация больших lookup-таблиц.
