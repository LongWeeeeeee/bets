> Generated on 2026-06-03 (migrated from AGENTS.md — НЕ верифицировано против исходников). Запусти subagent `scribe`, чтобы обогатить и проверить этот док против реального кода. Если код противоречит этому доку — верь коду.

# CODE_MAP — карта файлов проекта

## Дерево

```
├── base/                  # Основной код аналитики
│   ├── cyberscore_try.py  # ⭐ ГЛАВНЫЙ ФАЙЛ — live runtime, парсинг, API
│   ├── functions.py       # Хелперы: synergy, comeback metrics, вывод
│   ├── id_to_names.py     # Справочник команд (tier1/tier2 списки)
│   ├── maps_research.py   # Исследование карт
│   ├── check_old_maps.py  # Offline-сбор метрик по историческим картам
│   ├── metrics_winrate.py # Bucket winrate по JSON из check_old_maps.py
│   ├── analise_database.py
│   ├── explore_database.py
│   ├── bookmaker_selenium_odds.py  # Selenium/Camoufox парсинг букмекеров
│   └── tests/             # Тесты интеграции
├── ELO/                   # ELO-система для прогноза победителя серии
│   ├── models.py
│   ├── config.py
│   ├── run_series_experiment.py
│   └── output/            # Артефакты экспериментов
├── data/                  # Кэш и данные
├── pro_heroes_data/       # Данные про-героев
├── bets_data/             # Логи ставок и анализа
└── runtime/               # Runtime-файлы (lock-файлы, состояние) — git-ignored
```

---

## `base/cyberscore_try.py` (750KB+)

Главный файл: live-парсинг DLTV (Camoufox-first, Selenium fallback), краулинг букмекеров (Camoufox-first через subprocess, Selenium fallback), Telegram-нотификации, ML-предиктор, runtime-менеджмент (lock-файлы, sharded stats).

> ⚠️ Не читай файл целиком (750KB+). Используй `grep`/`rg` по имени функции + точечные чтения по диапазону строк.

**Важные функции:** `send_message()`, `drain_telegram_admin_commands()`, `synergy_and_counterpick()`, `_ensure_camoufox_browser()`, `_bookmaker_prefetch_fetch_camoufox_direct()`.

**Режимы запуска:** `--no-odds` (только DLTV, ОСНОВНОЙ), `--odds` (с букмекерскими кэфами), `--bookmaker-gate-mode {odds,presence}`.

**Режим minimal_odds_only:** `SIGNAL_MINIMAL_ODDS_ONLY_MODE=1` — только команды + счёт + кэфы, без dota2protracker и словарей.

**Переменные окружения:**
- `BOOKMAKER_PROXY_URL`, `BOOKMAKER_PROXY_POOL` — прокси для букмекеров
- `DLTV_PROXY_POOL` — прокси для DLTV
- `DLTV_CAMOUFOX_ENABLED=1` — Camoufox-first для DLTV HTML mode
- `BOOKMAKER_CAMOUFOX_ENABLED=1` — Camoufox для bookmaker (ОСНОВНОЙ РЕЖИМ)
- `SIGNAL_MINIMAL_ODDS_ONLY_MODE=1` — режим "только команды + счёт + кэфы"
- `DOTA2PROTRACKER_ENABLED=0` — отключить парсинг pro-tracker
- `BOOKMAKER_PREFETCH_MESSAGE_WAIT_SECONDS=10` — ожидание кэфов перед отправкой
- При удалении нерабочих прокси в `base/keys.py` чистим только runtime proxy constants/pools; не трогаем `api_to_proxy` / `api_to_keys` и API-ключи.

**Пример запуска локально:**
```bash
SIGNAL_MINIMAL_ODDS_ONLY_MODE=1 DOTA2PROTRACKER_ENABLED=0 \
BOOKMAKER_CAMOUFOX_ENABLED=1 BOOKMAKER_PREFETCH_MESSAGE_WAIT_SECONDS=10 \
/Users/alex/Documents/ingame/venv_catboost/bin/python3 \
/Users/alex/Documents/ingame/base/cyberscore_try.py --odds
```

**Пример запуска на сервере:**
```bash
SIGNAL_MINIMAL_ODDS_ONLY_MODE=1 DOTA2PROTRACKER_ENABLED=0 \
BOOKMAKER_CAMOUFOX_ENABLED=1 BOOKMAKER_PREFETCH_MESSAGE_WAIT_SECONDS=10 \
python3 base/cyberscore_try.py --odds
```

---

## `base/functions.py`

Общие хелперы (synergy, comeback metrics, вывод). Импортируется в `cyberscore_try.py`.

---

## `base/check_old_maps.py` — offline-проверка draft-метрик

Прогоняет исторические карты через те же draft-метрики, что в Telegram-сигнале: словари `early_dict_raw`, `late_dict_raw`, `lane_dict_raw`, `post_lane_dict_raw`; `dota2protracker` cp1vs1, synergy_duo, lane_advantage; lane/early/late/post-lane outcomes. Публичные матчи по патчам в `bets_data/analise_pub_matches/json_parts_split_from_object/`. Для split-файлов можно передавать директорию и `--patch`; `--patch 7.41` использует start timestamp `1774310400`.

Пример 50k public backtest (patch 7.41):
```bash
/Users/alex/Documents/ingame/venv_catboost/bin/python3 base/check_old_maps.py \
  --maps-path bets_data/analise_pub_matches/json_parts_split_from_object \
  --patch 7.41 \
  --max-matches 50000 \
  --dicts \
  --dota2protracker \
  --post-lane-max-cached-shards 127 \
  --output runtime/pub_7.41_50k_metrics.json
```
`--post-lane-max-cached-shards 127` — только для offline backtest на больших public выборках; live-логику не меняет.

Bucket winrate:
```bash
/Users/alex/Documents/ingame/venv_catboost/bin/python3 base/metrics_winrate.py \
  --input runtime/pub_7.41_50k_metrics.json \
  --bucket-mode \
  --min-matches 6 \
  > runtime/pub_7.41_50k_winrate.txt
```
Для pro-match — тот же pipeline (`runtime/pro_maps_metrics_*.json` → `*_winrate.txt`).

---

## `base/dota2protracker.py`

Парсер hero matchups/synergies с dota2protracker.com (Selenium/Camoufox для обхода Cloudflare). Hero ID в HERO_ID_MAP — OpenDota IDs. cp1vs1 и duo_synergy из pro-игр (10+ матчей). Кэш в `hero_dota2protracker_data/`. `DOTA2PROTRACKER_ENABLED=0` для отключения.

**Поведение интеграции:** enrichment сразу после успешного парса драфта; метрики выводятся отдельным Telegram-блоком (`dota2protracker:`, `cp1vs1`, `synergy_duo`). `DOTA2PROTRACKER_ONLY_MODE=1` — минимальное сообщение только с dota2protracker; `+ DOTA2PROTRACKER_BYPASS_GATES=1` — отправка на любой валидный драфт без star/networth gate.

**Bookmaker Camoufox-интеграция:** `base/bookmaker_selenium_odds.py` умеет `presence`, `odds`, `deeplink` через Camoufox. При `BOOKMAKER_CAMOUFOX_ENABLED=1` subprocess-путь не строит Selenium для odds/deeplink, а `BOOKMAKER_PREFETCH_USE_SUBPROCESS` включается автоматически. Перед отправкой делается повторный bookmaker subprocess-refresh, чтобы кэфы были ближе к dispatch.

**Математика:**
- `cp1vs1` и `duo_synergy` — только по exact position-pair данным; старый fallback на агрегированные legacy matchups/synergies отключён.
- `cp1vs1_valid=True`, если у каждого из 6 core-героев (radiant pos1/2/3, dire pos1/2/3) есть минимум 2 валидных core-vs-core значения.
- `synergy_duo` считается по всем 5 позициям, валидность держится на coverage core-позиций.

**Lane-specific (lane_advantage)** — `calculate_lane_advantage()` считает cp1vs1 и duo_synergy по лейнам:

| Лейн | cp1vs1 matchups | duo synergy |
|------|-----------------|------------|
| **mid** | pos2 vs pos2 | нет |
| **top** | pos3 vs pos1, pos3 vs pos5, pos4 vs pos1, pos4 vs pos5 | radiant pos3+pos4 vs dire pos1+pos5 |
| **bot** | pos1 vs pos3, pos1 vs pos4, pos5 vs pos3, pos5 vs pos4 | radiant pos1+pos5 vs dire pos3+pos4 |

Валидация: cp1vs1 mid=1/1, top/bot=2/4 matchups (мин. 10 игр каждый); duo — валидная синергия с обеих сторон. Результат: `pro_lane_{mid,top,bot}_cp1vs1`, `pro_lane_{top,bot}_duo`, `pro_lane_advantage` (усреднение валидных) + `*_valid` флаги. Lookups: `_get_matchup_1v1()` и `_get_duo_synergy_pair()` берут направление с большим числом игр.

---

## `base/id_to_names.py`

Справочник команд с динамическим onboarding (auto-added секции внизу файла). `tier_one_teams` — dict {name: team_id}, `tier_two_teams` — dict {name: team_id}.

---

## `ELO/run_series_experiment.py`

```bash
source venv_catboost/bin/activate
python ELO/run_series_experiment.py
```

---

## Тесты (`base/tests/`)

```bash
pytest base/tests/ -v
```
Основные: `test_pipeline_integrity.py`, `test_networth_dispatch_gates.py`, `test_tier_threshold_switch.py`, `test_explore_database_integrity.py`.
