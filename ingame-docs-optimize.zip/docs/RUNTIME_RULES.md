> Generated on 2026-06-03 (migrated from AGENTS.md). Развёрнутые операционные правила и деплой. Краткая версия-инвариант — в корневом `AGENTS.md`. Если код противоречит этому доку — верь коду.

# RUNTIME RULES — развёрнуто

## Операционные правила

- **Всегда отвечай пользователю на русском.** Код, идентификаторы, commit-сообщения и строки логов остаются на исходном языке, но все объяснения, резюме и ответы в чате — на русском.
- Агент не делает ничего своевольного сверх поставленной задачи или явных предписаний в проектных `.md` файлах; выполняй задачу и ничего больше.
- Если запрос неоднозначен, агент не уверен, или у пользователя логическая ошибка — сначала спроси пользователя.
- **Виртуальное окружение:** всегда используй `/Users/alex/Documents/ingame/venv_catboost/bin/python3`. Активация: `source venv_catboost/bin/activate` из `/Users/alex/Documents/ingame`. Не создавай и не используй другие venv.
- **Не запускай и не перезапускай локальный `base/cyberscore_try.py` runtime** без явного запроса пользователя. Изменения в live pipeline реализуй и тестируй без запуска локального runtime по умолчанию.
- Для любого перезапуска live runtime: сначала убей старые `cyberscore` процессы, очисти `~/.local/state/ingame/map_id_check.txt`, и только при **bug fix** усеки активный лог сервера (`/root/main/log.txt`) перед стартом.
- **map_id_check единый для всех режимов** (`--odds`, `--no-odds`, presence и т.д.) — путь `~/.local/state/ingame/map_id_check.txt` (`MAP_ID_CHECK_PATH`). При любом перезапуске чисти его.
- **Политика `log.txt`:** НЕ усекай лог во время тестов, проб или mid-investigation рестартов. Усекай ТОЛЬКО при bug fix (git push → production pull → restart). Логические изменения (новые пороги, dispatch-правила, твики множителей) лог НЕ чистят.
- Перед входом live runtime в основной CyberScore/DLTV цикл: валидируй каждый live-прокси до 3 раз; мёртвые прокси немедленно убирай из in-memory live proxy pool. Не трогай маппинги API-ключей в `base/keys.py` при этом pruning.
- После изменений в `cyberscore` live pipeline (`base/cyberscore_try.py`, `base/functions.py`, `base/dota2protracker.py`, bookmaker/live dispatch): запушь commit в `main`, подтяни код на production, убей старый процесс, очисти `map_id_check.txt`, перезапусти runtime с новым кодом.
- При удалении нерабочих прокси в `base/keys.py` убирай их только из runtime proxy constants/pools; НЕ удаляй и НЕ меняй записи `api_to_proxy` / `api_to_keys` и связанные API-ключи.
- **Rebuild-then-replace, никогда delete-then-create.** При регенерации словаря, sqlite DB, снапшота или артефакта пиши новую версию во временный путь (`<target>.tmp`) и атомарно переименовывай поверх только после успешной сборки.
- **Никогда не удаляй файлы, директории, бэкапы или артефакты** (локально или на сервере) без явного подтверждения пользователя.
- **Долгие локальные задачи** запускай в фоне через `nohup` с логами/pid под `runtime/`. НИКОГДА не используй встроенный background-process инструмент для долгих задач — всегда `nohup ... > runtime/<name>.log 2>&1 &` с `echo $!` для PID. Всегда сообщай кликабельную ссылку на лог и команду проверки состояния процесса.
- **Production server:** `root@147.45.216.225`, путь проекта `/root/main`.
- Runtime/output артефакты под `runtime/` намеренно игнорируются.

---

## Запуск и деплой на сервере

**Перед запуском всегда проверяй уже запущенную версию и убивай предыдущий процесс:**

```bash
# Проверить запущенные процессы
ps aux | grep cyberscore
pgrep -f cyberscore

# Убить предыдущий процесс
pkill -f cyberscore
# или по PID
kill <PID>
```

Затем очистить map_id_check для переанализа матчей:
```bash
rm -f ~/.local/state/ingame/map_id_check.txt
```

**Деплой изменений:**
1. Git: `git add . && git commit -m "message" && git push origin main`
2. На сервере: `cd /root/main && git pull origin main`
3. Если сервер без git — rsync:
   ```bash
   rsync -avz --exclude='venv*' --exclude='__pycache__' --exclude='*.log' \
     ELO/ base/ root@147.45.216.225:/root/main/
   ```
4. Очистить map_id_check: `rm -f ~/.local/state/ingame/map_id_check.txt`

Запуск:
```bash
cd /root/main
source venv/bin/activate
python3 base/cyberscore_try.py --no-odds
```

---

## Tips для агента

1. **Не читай весь `cyberscore_try.py`** — он 750KB+. Используй `grep`/`rg` для поиска функций.
2. **Букмекерский краулинг** — через Selenium (headless Chrome) и Camoufox.
3. **Proxy пулы** — настраиваются в `base/keys.py`.
4. **Lock-файлы** — против multiple instances.
5. **Sharded stats** — оптимизация больших lookup-таблиц.
