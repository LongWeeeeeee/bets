> Generated on 2026-06-03 (migrated from AGENTS.md — НЕ верифицировано против исходников). Запусти subagent `scribe`, чтобы добавить точный сквозной поток данных и проверить против кода. Если код противоречит этому доку — верь коду.

# ARCHITECTURE — концепции и поток данных

## Поток данных сигнала (заполняется scribe)

> TODO(scribe): описать сквозной pipeline live-сигнала:
> live fetch (CyberScore/DLTV) → парс драфта → draft-метрики (early/late/lane/post-lane + dota2protracker) → gates (networth / star thresholds) → решение о STAR → отправка в Telegram (+ mirror VK).
> Указать ключевые функции каждого этапа и где они в `base/cyberscore_try.py`.

---

## Основные концепции

### Tier-классификация команд
- **tier1**: топ-команды (~60+) — активный рейтинг, полный вес матчей
- **tier2**: полупро — локальный рейтинг, меньший вес
- **tier3**: остальные — минимальный вес

Команды в `base/id_to_names.py`: `tier_one_teams` — dict {name: team_id}, `tier_two_teams` — dict {name: team_id}.

### Roster Lock
Если >=3 игроков совпадают с последним матчем org, состав продолжает ту же линию, иначе — новый segment.

### Star System
Метрики comeback-моделей с порогами `STAR_THRESHOLDS_BY_WR` (Win Rate based). В STAR-сигнале участвуют: `counterpick_1vs1`, `dota2protracker_cp1vs1`, `counterpick_1vs2`, `solo`. `synergy_duo` и `synergy_trio` могут выводиться в Telegram-блоках/таблицах, но сейчас НЕ участвуют в принятии решения о STAR-сигнале.

### ML-модели
- **Ultimate Inference**: `src/live_predictor.py` — предсказание live-матчей. `LIVE_PREDICTOR_AVAILABLE = True`, если файл найден.
- **CatBoost**: для различных классификаций.
- Данные в `base/ml_dataset/`.
